$(document).ready(function(){
	//initialise our accordian
	$("#accordian").accordian({
		defaultIndex : 1
	});
});